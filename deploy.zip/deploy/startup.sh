#!/bin/bash
gunicorn --bind=0.0.0.0 --worker-class aiohttp.worker.GunicornWebWorker app:APP
