"""Gap Analysis Bot - M365 Teams Agent."""
__version__ = "1.0.0"
